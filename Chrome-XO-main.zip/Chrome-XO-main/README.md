# Chrome-XO
Use the Google Chrome browser with: no ads, AMOLED, extentions, access to Chrome web store, icon cutomization, additional settings, and more.
